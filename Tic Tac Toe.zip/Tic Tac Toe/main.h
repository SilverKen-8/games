#ifndef MAIN_H_INCLUDED
#define MAIN_H_INCLUDED

#define WINDOW_SIZE_H 408
#define WINDOW_SIZE_W 408
#define TAILLE_CASE 136
#define NB_BLOCS_W 3
#define NB_BLOCS_H 3

enum {VIDE, ROND, CROIX, CROIX_OK, ROND_OK};

#endif // MAIN_H_INCLUDED
