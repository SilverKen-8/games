#include <SDL/SDL.h>
#include <SDL_image.h>
#include "main.h"
#include "jouer.h"

int main(int argc, char *argv[])
{
    SDL_Init(SDL_INIT_VIDEO);
    SDL_WM_SetCaption("Tic Tac Toe", NULL);
    SDL_Surface *ecran, *grille, *rond, *croix, *croix_ok, *rond_ok, *icone;
    icone = IMG_Load("sprites/icone.png");
    SDL_WM_SetIcon(icone, NULL);
    ecran = SDL_SetVideoMode(WINDOW_SIZE_W, WINDOW_SIZE_H, 32, SDL_HWSURFACE);
    grille = IMG_Load("sprites/grille.png");
    rond = IMG_Load("sprites/rond.png");
    croix = IMG_Load("sprites/croix.png");
    rond_ok = IMG_Load("sprites/rond_ok.png");
    croix_ok = IMG_Load("sprites/croix_ok.png");
    SDL_Rect positionGrille;
    positionGrille.x = 0;
    positionGrille.y = 0;
    SDL_BlitSurface(grille, NULL, ecran, &positionGrille);

    jouer(ecran, rond, croix, rond_ok, croix_ok);

    SDL_FreeSurface(rond);
    SDL_FreeSurface(croix);
    SDL_FreeSurface(croix_ok);
    SDL_FreeSurface(rond_ok);
    SDL_Quit();
    return EXIT_SUCCESS;
}
