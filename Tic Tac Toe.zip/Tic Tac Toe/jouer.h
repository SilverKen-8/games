#ifndef JOUER_H_INCLUDED
#define JOUER_H_INCLUDED

void jouer(SDL_Surface *ecran, SDL_Surface *rond, SDL_Surface *croix, SDL_Surface *rond_ok, SDL_Surface *croix_ok);
void swapObjets(int *objetActuel, int valeur1, int valeur2);
int testGagne(int carte[3][3]);

#endif // JOUER_H_INCLUDED
