#include <SDL/SDL.h>
#include "main.h"
#include "jouer.h"

void jouer(SDL_Surface *ecran, SDL_Surface *rond, SDL_Surface *croix, SDL_Surface *rond_ok, SDL_Surface *croix_ok)
{
    //Mode Multi
    int continuer = 1, i = 0, j = 0;
    int objetActuel = ROND;
    int carte[3][3] = {0};
    SDL_Rect positionSurCarte;

    SDL_Event event;
    while(continuer)
    {
        SDL_WaitEvent(&event);

        switch(event.type)
        {
        case SDL_MOUSEBUTTONDOWN:
            if(event.button.button == SDL_BUTTON_LEFT)
            {
                if(event.button.button == SDL_BUTTON_LEFT);
                {
                    if(carte[event.button.x / TAILLE_CASE][event.button.y / TAILLE_CASE] == VIDE)
                    {
                        swapObjets(&objetActuel, CROIX, ROND);
                        carte[event.button.x / TAILLE_CASE][event.button.y / TAILLE_CASE] = objetActuel;
                    }

                }
            }
            break;

        case SDL_QUIT:
            continuer = 0;
            break;
        }

        for(i = 0; i < NB_BLOCS_W; i++)
        {
            for(j = 0; j < NB_BLOCS_H; j++)
            {
                positionSurCarte.x = i * TAILLE_CASE + 10;
                positionSurCarte.y = j * TAILLE_CASE + 10;

                switch(carte[i][j])
                {
                case CROIX:
                    if(testGagne(carte) && objetActuel == CROIX)
                    {
                        SDL_BlitSurface(croix_ok, NULL, ecran, &positionSurCarte);
                        continuer = 0;
                    }
                    else
                    {
                        SDL_BlitSurface(croix, NULL, ecran, &positionSurCarte);
                    }
                    break;

                case ROND:
                    if(testGagne(carte) && objetActuel == ROND)
                    {
                        SDL_BlitSurface(rond_ok, NULL, ecran, &positionSurCarte);
                        continuer = 0;
                    }
                    else
                    {
                        SDL_BlitSurface(rond, NULL, ecran, &positionSurCarte);
                    }
                    break;

                case VIDE:
                    break;
                }
            }
        }

        SDL_Flip(ecran);
    }
    if(testGagne(carte))
        SDL_Delay(2000);
}

void swapObjets(int *objetActuel, int valeur1, int valeur2)
{
    if(*objetActuel == valeur1)
        *objetActuel = valeur2;

    else if(*objetActuel == valeur2)
        *objetActuel = valeur1;
}

int testGagne(int carte[3][3])
{
    if((carte[1][0] == CROIX && carte[1][1] == CROIX && carte[1][2] == CROIX) || (carte[1][0] == ROND && carte[1][1] == ROND && carte[1][2] == ROND))
        return 1;

    else if((carte[0][0] == CROIX && carte[0][1] == CROIX && carte[0][2] == CROIX) || (carte[0][0] == ROND && carte[0][1] == ROND && carte[0][2] == ROND))
        return 1;

    else if((carte[0][0] == CROIX && carte[1][0] == CROIX && carte[2][0] == CROIX) || (carte[0][0] == ROND && carte[1][0] == ROND && carte[2][0] == ROND))
        return 1;

    else if((carte[0][1] == CROIX && carte[1][1] == CROIX && carte[2][1] == CROIX) || (carte[0][1] == ROND && carte[1][1] == ROND && carte[2][1] == ROND))
        return 1;

    else if((carte[0][2] == CROIX && carte[1][2] == CROIX && carte[2][2] == CROIX) || (carte[0][2] == ROND && carte[1][2] == ROND && carte[2][2] == ROND))
        return 1;

    else if((carte[2][0] == CROIX && carte[2][1] == CROIX && carte[2][2] == CROIX) || (carte[2][0] == ROND && carte[2][1] == ROND && carte[2][2] == ROND))
        return 1;

    else if((carte[0][0] == CROIX && carte[1][1] == CROIX && carte[2][2] == CROIX) || (carte[0][0] == ROND && carte[1][1] == ROND && carte[2][2] == ROND))
        return 1;

    else if((carte[2][0] == CROIX && carte[1][1] == CROIX && carte[0][2] == CROIX) || (carte[2][0] == ROND && carte[1][1] == ROND && carte[0][2] == ROND))
        return 1;
    else
        return 0;
}

